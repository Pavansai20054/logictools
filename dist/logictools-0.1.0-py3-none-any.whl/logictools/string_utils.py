def convert_to_uppercase(text):
    return text.upper()        #Converts a string to uppercase.

def reverse_string(text):
    return text[::-1]          #Reverses a given string.

def word_count(text):
    return len(text)           #Gives the length of the string.