from .string_utils import convert_to_uppercase, reverse_string, word_count
from .math_utils import factorial
